function skinsInit() {
    CopyslFbox08c591f4ad0bc46 = "CopyslFbox08c591f4ad0bc46";
    CopyslFbox0e785db2e997542 = "CopyslFbox0e785db2e997542";
    CopyslForm0c9d0953a4c0247 = "CopyslForm0c9d0953a4c0247";
    lines = "lines";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slFbox = "slFbox";
    slForm = "slForm";
    slImage = "slImage";
    slLabel = "slLabel";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};