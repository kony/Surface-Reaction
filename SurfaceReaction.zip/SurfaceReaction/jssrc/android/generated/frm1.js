function addWidgetsfrm1() {
    frm1.setDefaultUnit(kony.flex.DP);
    var image1 = new kony.ui.Image2({
        "centerX": "25%",
        "centerY": "12.50%",
        "height": "25%",
        "id": "image1",
        "isVisible": true,
        "onTouchStart": AS_Image_108330a369df4b23b2a6d0d8d642f576,
        "skin": "slImage",
        "src": "kitty1.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image2 = new kony.ui.Image2({
        "centerX": "75%",
        "centerY": "12.50%",
        "height": "25%",
        "id": "image2",
        "isVisible": true,
        "onTouchStart": AS_Image_dd6eabb2a94441e9984494b14c68e7f8,
        "skin": "slImage",
        "src": "water1.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image3 = new kony.ui.Image2({
        "centerX": "25.00%",
        "centerY": "37.51%",
        "height": "25%",
        "id": "image3",
        "isVisible": true,
        "onTouchStart": AS_Image_9212d4ac32264824830d6507e7ce7421,
        "skin": "slImage",
        "src": "b.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image4 = new kony.ui.Image2({
        "centerX": "75%",
        "centerY": "37.50%",
        "height": "25%",
        "id": "image4",
        "isVisible": true,
        "onTouchStart": AS_Image_3e0906ec5a094d2c902a409e6122c921,
        "skin": "slImage",
        "src": "dna.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image5 = new kony.ui.Image2({
        "centerX": "25%",
        "centerY": "62.50%",
        "height": "25%",
        "id": "image5",
        "isVisible": true,
        "onTouchStart": AS_Image_567b561faf514cf28fabc80543c05c2d,
        "skin": "slImage",
        "src": "pup2.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image6 = new kony.ui.Image2({
        "centerX": "75.00%",
        "centerY": "62.50%",
        "height": "25%",
        "id": "image6",
        "isVisible": true,
        "onTouchStart": AS_Image_c7f154209d194769aa200b0242cc646f,
        "skin": "slImage",
        "src": "panda.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image7 = new kony.ui.Image2({
        "centerX": "25%",
        "centerY": "87.50%",
        "height": "25%",
        "id": "image7",
        "isVisible": true,
        "onTouchStart": AS_Image_1d387d2f26dc4a05970580deee806f15,
        "skin": "slImage",
        "src": "birds.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image8 = new kony.ui.Image2({
        "centerX": "75%",
        "centerY": "87.50%",
        "height": "25%",
        "id": "image8",
        "isVisible": true,
        "onTouchStart": AS_Image_6d5506a8f7a44c41aee8778742838899,
        "skin": "slImage",
        "src": "g.png",
        "width": "50%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var boarderCont = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "220dp",
        "id": "boarderCont",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "8dp",
        "skin": "slFbox",
        "top": "51dp",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    boarderCont.setDefaultUnit(kony.flex.DP);
    var rippleCont = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "95dp",
        "centerY": "85dp",
        "clipBounds": true,
        "height": "100dp",
        "id": "rippleCont",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "skin": "CopyslFbox08c591f4ad0bc46",
        "top": "98dp",
        "width": "100dp",
        "zIndex": 3
    }, {}, {});
    rippleCont.setDefaultUnit(kony.flex.DP);
    var dummy = new kony.ui.Label({
        "id": "dummy",
        "isVisible": false,
        "left": "110dp",
        "skin": "slLabel",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "106dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    rippleCont.add(dummy);
    boarderCont.add(rippleCont);
    var vline1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "100%",
        "id": "vline1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "1%",
        "zIndex": 3
    }, {}, {});
    vline1.setDefaultUnit(kony.flex.DP);
    vline1.add();
    var vline2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "100%",
        "id": "vline2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0e785db2e997542",
        "width": "1%",
        "zIndex": 3
    }, {}, {});
    vline2.setDefaultUnit(kony.flex.DP);
    vline2.add();
    var vline3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "100%",
        "id": "vline3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0e785db2e997542",
        "width": "1%",
        "zIndex": 3
    }, {}, {});
    vline3.setDefaultUnit(kony.flex.DP);
    vline3.add();
    var hline1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "0%",
        "clipBounds": true,
        "height": "1%",
        "id": "hline1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    hline1.setDefaultUnit(kony.flex.DP);
    hline1.add();
    var hline2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "25%",
        "clipBounds": true,
        "height": "1%",
        "id": "hline2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    hline2.setDefaultUnit(kony.flex.DP);
    hline2.add();
    var hline3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "1%",
        "id": "hline3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    hline3.setDefaultUnit(kony.flex.DP);
    hline3.add();
    var hline4 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "75%",
        "clipBounds": true,
        "height": "1%",
        "id": "hline4",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    hline4.setDefaultUnit(kony.flex.DP);
    hline4.add();
    var hline5 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "100%",
        "clipBounds": true,
        "height": "1%",
        "id": "hline5",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "lines",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    hline5.setDefaultUnit(kony.flex.DP);
    hline5.add();
    frm1.add(image1, image2, image3, image4, image5, image6, image7, image8, boarderCont, vline1, vline2, vline3, hline1, hline2, hline3, hline4, hline5);
};

function frm1Globals() {
    frm1 = new kony.ui.Form2({
        "addWidgets": addWidgetsfrm1,
        "enabledForIdleTimeout": false,
        "id": "frm1",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0c9d0953a4c0247"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};