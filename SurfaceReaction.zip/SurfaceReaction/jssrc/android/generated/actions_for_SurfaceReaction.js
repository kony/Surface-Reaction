//actions.js file 
function AS_Image_108330a369df4b23b2a6d0d8d642f576(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_1d387d2f26dc4a05970580deee806f15(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_3e0906ec5a094d2c902a409e6122c921(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_567b561faf514cf28fabc80543c05c2d(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_6d5506a8f7a44c41aee8778742838899(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_9212d4ac32264824830d6507e7ce7421(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_c7f154209d194769aa200b0242cc646f(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}

function AS_Image_dd6eabb2a94441e9984494b14c68e7f8(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}