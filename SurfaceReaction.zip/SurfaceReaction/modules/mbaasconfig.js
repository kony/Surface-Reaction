function getKonyMBAASAppKey()
{
	return $appKey;
}

function getKonyMBAASAppSecret()
{
	return $appSecret;
}
