function AS_Image_c7f154209d194769aa200b0242cc646f(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}