function AS_Image_3e0906ec5a094d2c902a409e6122c921(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}