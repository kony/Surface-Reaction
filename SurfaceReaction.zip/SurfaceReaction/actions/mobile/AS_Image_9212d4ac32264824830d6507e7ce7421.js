function AS_Image_9212d4ac32264824830d6507e7ce7421(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}