function AS_Image_6d5506a8f7a44c41aee8778742838899(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}