function AS_Image_567b561faf514cf28fabc80543c05c2d(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}