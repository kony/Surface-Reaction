function AS_Image_dd6eabb2a94441e9984494b14c68e7f8(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}