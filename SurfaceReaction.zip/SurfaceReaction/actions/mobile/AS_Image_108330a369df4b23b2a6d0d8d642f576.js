function AS_Image_108330a369df4b23b2a6d0d8d642f576(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}