function AS_Image_1d387d2f26dc4a05970580deee806f15(eventobject, x, y) {
    return surfaceReaction.call(this, eventobject.id);
}